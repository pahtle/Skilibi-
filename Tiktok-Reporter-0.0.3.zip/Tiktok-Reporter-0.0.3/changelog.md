# Version 0.0.3
    - Fixed:
      - tls-client pip install.
    - Removed:
      - Removed cloned functions.
    - Added:
      - Option to use selenium to gather user information if the requests doesn't work.

# Version 0.0.1.1
    - Hotfix on requirements

# Version 0.0.1
    - First Commit.
